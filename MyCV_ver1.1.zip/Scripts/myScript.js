﻿/// <reference path="angular.js" />

var app = angular.module("myCV", []);
app.controller("myBasicInfor", function ($scope, $http) {
    $http.get('basicInfor.json').then(function (res) {
        $scope.infor = res.data;
    });
});
